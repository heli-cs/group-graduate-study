
Mask Dataset - v1 2020-11-13 3:11pm
==============================

This dataset was exported via roboflow.ai on January 14, 2021 at 10:02 AM GMT

It includes 800 images.
Mask are annotated in Pascal VOC format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

No image augmentation techniques were applied.


